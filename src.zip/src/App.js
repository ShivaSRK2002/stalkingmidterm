import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './components/HomePage';
import ComplaintMultiForm from './components/ComplaintMultiForm';
import LoadingScreen from './components/LoadingScreen';
import ComplaintList from './components/ComplaintList'; // New component for displaying complaints
import UserCases from './components/UserCases'; // Import UserCases component
import TargetCallbackHandler from './TargetCallbackHandler';

function App() {
  const [loading, setLoading] = useState(false);
  const [complaints, setComplaints] = useState([]); // State to hold all complaints

  // Handle loading state (for transitions or form submission)
  const handleLoading = (isLoading) => {
    setLoading(isLoading);
  };

  // Function to handle form submission and store complaints
  const handleSubmitComplaint = (newComplaintData) => {
    setComplaints((prevComplaints) => [...prevComplaints, newComplaintData]); // Store the new complaint
  };

  return (
    <div className="App">
      <Router>
        {loading && <LoadingScreen />} {/* Show loading screen if `loading` is true */}
        
        
        <Routes>
          {/* Home Page */}
          <Route 
            path="/" 
            element={<TargetCallbackHandler />} 
          />
          <Route 
            path="/HomePage" 
            element={<HomePage />} 
          />

          {/* Complaint Form Page */}
          <Route 
            path="/complaint-form" 
            element={<ComplaintMultiForm setLoading={handleLoading} handleSubmit={handleSubmitComplaint} />} 
          />

          {/* Complaints List Page */}
          <Route 
            path="/complaint-list" 
            element={<ComplaintList complaints={complaints} />} // Pass complaints to the list page
          />

          {/* User Cases Page */}
          <Route 
            path="/user-cases" 
            element={<UserCases />} // Render the UserCases component
          />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
