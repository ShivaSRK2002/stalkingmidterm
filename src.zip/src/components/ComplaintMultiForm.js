import React, { useState } from 'react';
import { Fade, Box, CircularProgress } from '@mui/material';
import axios from 'axios';
import ComplaintOverview from './ComplaintOverview';
import IncidentDetails from './IncidentDetails';
import ComplainantInformation from './ComplainantInformation';
import Evidence from './Evidence';
import ReviewAndSubmit from './ReviewAndSubmit';
import SuspectInformation from './SuspectInformation';

const ComplaintMultiForm = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    categoryid: 24,
    userid: 116,
    policeid: 2002,
    reasonforwithdrawal: null,
    iswithdrawalaccepted: 0,
    iswithdrawn: 0,
    iscomplaintaccepted: 1,
    casestatus: 'under investigation',
    isfirfiled: 1,
    
    individualDetails: {
      victim_name: '',
      incident_date: '',
      location: '',
      locationOfIncident: '',
      dateOfIncident: '',
      incidentDescription: '',
      fullName: '',
      contactNumber: '',
      emailAddress: '',
      suspectDescription: '',
      relationToComplainant: '',
      linksToEvidence: '',
      requestForAction: '',
      adminComments: '',
      evidenceFiles: [], // Add evidence files array for upload
    aadhaarUpload: null, // Aadhaar file for upload
    },
  });

  const [loading, setLoading] = useState(false);
  const token = 'eyJraWQiOiJPMGgyenNCR2lacnlSTzBkNklqdDI1SzdteldpREJKejdhK0lBV2R6XC9yVT0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJlODMxZjMyMC0zMDQxLTcwYzctYjcxYS0zZGUzNjc1ZDVkNmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYmlydGhkYXRlIjoiMjBcLzEwXC8yMDAyIiwiZ2VuZGVyIjoiTWFsZSIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy13ZXN0LTIuYW1hem9uYXdzLmNvbVwvdXMtd2VzdC0yX1FQdUpmT2FGYyIsInBob25lX251bWJlcl92ZXJpZmllZCI6ZmFsc2UsImNvZ25pdG86dXNlcm5hbWUiOiJlODMxZjMyMC0zMDQxLTcwYzctYjcxYS0zZGUzNjc1ZDVkNmMiLCJvcmlnaW5fanRpIjoiNjg4MTBhNWYtZDNhMi00Yzk2LWE2OGEtYzZjNjUzOWRlOWYwIiwiYXVkIjoiMm1udjE3dm9hN2U4cTZiYW5sZzBqMHF0aCIsImV2ZW50X2lkIjoiMmFlZTdiNDMtM2FmOC00OGIyLWE2MTgtM2VhNWY2MTYwZTgwIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE3MzE1ODA5NTgsIm5hbWUiOiJTaGl2YSIsInBob25lX251bWJlciI6Iis5MTg4MjU3OTIyNjUiLCJleHAiOjE3MzE2NjczNTgsImlhdCI6MTczMTU4MDk1OCwianRpIjoiMzU5MmIxMTEtMzg3YS00NWJkLTg4ODEtN2Q5MmZjMTJmODI4IiwiZW1haWwiOiJzaGl2YXJhbWFrcnNobm5AZ21haWwuY29tIn0.EXBMHT6-0UqDVzH9_CeA0MeIbKbgXvcdNK80PYRElP3XOt2yvbBIHeluLg26OQbxu1us6l0LPGm3iW2kzlXe79-osWfm9xPqvm-RUQ2a4hofi9bcm2kZmh1fwaMArCtYtWo5q82-MzujTuSRT_sRxuHRnSzsW5gGLQMYbJTQrdnFMTJbK0WjEONM2Jjp-BN9RAS3FtCY4A8-AmW23GXfcijRjMquiE5MwV9GFRYS5DlM1OIzKRz-tZuYO4_hh55oDV3VxfJhNGvXlKSB0T_gyoKOmgNweD663sGqcdCwSwrQGueJCXkXtnxlUAu5AXVFZkvm8Urpi4ymoDo6D6RA5Q'; // Replace with actual token logic

  const nextStep = () => setCurrentStep(prev => prev + 1);
  const prevStep = () => setCurrentStep(prev => prev - 1);

  const updateFormData = (input) => {
    setFormData(prev => ({ ...prev, ...input }));
  };

  const getPreSignedUrl = async (file, folderName, index) => {
    try {
      const formData = {
        body: {
          folderName,
          fileName: index === 0 ? 'victim_aadhaar' : `Evidence_${index}`,
          fileType: file.type,
          isEvidence: index !== 0,
        },
      };

      const response = await axios.post(
        'https://kz6gmd08a6.execute-api.ap-northeast-2.amazonaws.com/dev/uploadvideo',
        formData
      );
      const { url } = JSON.parse(response.data.body);
      return url;
    } catch (error) {
      console.error('Error getting pre-signed URL:', error);
      return null;
    }
  };

  const uploadFileToS3 = async (file, preSignedUrl) => {
    try {
      const response = await axios.put(preSignedUrl, file, {
        headers: { 'Content-Type': file.type },
      });

      if (response.status === 200) {
        console.log('File uploaded successfully!');
      }
    } catch (error) {
      console.error('Error uploading file to S3:', error);
    }
  };

  const uploadEvidenceFiles = async () => {
    for (let i = 0; i < formData.evidenceFiles.length; i++) {
      const file = formData.evidenceFiles[i];
      const folderName = '24-1';
      const preSignedUrl = await getPreSignedUrl(file, folderName, i + 1);
      if (preSignedUrl) await uploadFileToS3(file, preSignedUrl);
    }
  };

  const uploadAadhaarFile = async () => {
    const file = formData.aadhaarUpload;
    const folderName = '24-1';
    const preSignedUrl = await getPreSignedUrl(file, folderName, 0);
    if (preSignedUrl) await uploadFileToS3(file, preSignedUrl);
  };

  const handleSubmit = async () => {
    setLoading(true);

    try {
      await uploadAadhaarFile();
      await uploadEvidenceFiles();

      const payload = {
        ...formData,
        individualDetails: JSON.stringify(formData.individualDetails),
      };

      const apiUrl = 'https://8lhcpuuc3j.execute-api.eu-west-2.amazonaws.com/FIR';
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      const responseText = await response.text();
      const data = JSON.parse(responseText);

      if (response.ok) {
        alert('Complaint submitted successfully!');
        console.log('API response:', data);
      } else {
        console.error('API error:', data);
        alert(`Submission failed: ${data.error || 'Please check the input and try again.'}`);
      }
    } catch (error) {
      console.error('Error during submission:', error);
      alert('There was an error while submitting the complaint.');
    } finally {
      setLoading(false);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <ComplaintOverview nextStep={nextStep} updateFormData={updateFormData} formData={formData} />;
      case 2:
        return <IncidentDetails prevStep={prevStep} nextStep={nextStep} updateFormData={updateFormData} formData={formData} />;
      case 3:
        return <ComplainantInformation prevStep={prevStep} nextStep={nextStep} updateFormData={updateFormData} formData={formData} />;
      case 4:
        return <SuspectInformation prevStep={prevStep} nextStep={nextStep} updateFormData={updateFormData} formData={formData} />;
      case 5:
        return <Evidence prevStep={prevStep} nextStep={nextStep} updateFormData={updateFormData} formData={formData} />;
      case 6:
        return <ReviewAndSubmit prevStep={prevStep} handleSubmit={handleSubmit} formData={formData} />;
      default:
        return null;
    }
  };

  return (
    <Box sx={{ position: 'relative', padding: 3 }}>
      {renderStep()}
      {loading && (
        <Fade in={loading}>
          <CircularProgress
            size={50}
            sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)' }}
          />
        </Fade>
      )}
    </Box>
  );
};

export default ComplaintMultiForm;
