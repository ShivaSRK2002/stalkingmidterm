import React, { useState } from 'react';
import { Box, Typography, Button, CircularProgress, Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const ReviewAndSubmit = ({ prevStep, handleSubmit, formData }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const onSubmit = async () => {
    setLoading(true);
    setError(null);

    try {
      await handleSubmit();

      setTimeout(() => {
        setLoading(false);
        navigate('/complaint-list');
      }, 1000);
    } catch (err) {
      setError('Submission failed. Please try again.');
      console.error('Error during submission:', err);
      setLoading(false);
    }
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Review and Submit
      </Typography>
      <pre>{JSON.stringify(formData, null, 2)}</pre>
      {error && (
        <Alert severity="error" sx={{ my: 2 }}>
          {error}
        </Alert>
      )}
      <Button variant="outlined" color="secondary" onClick={prevStep} disabled={loading}>
        Previous
      </Button>
      <Button variant="contained" color="primary" onClick={onSubmit} disabled={loading} sx={{ ml: 2 }}>
        {loading ? <CircularProgress size={24} /> : 'Submit'}
      </Button>
    </Box>
  );
};

export default ReviewAndSubmit;
