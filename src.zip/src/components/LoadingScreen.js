// LoadingScreen.js
import React from "react";
import { motion } from "framer-motion";


const LoadingScreen = () => {
  return (
    <motion.div
      className="loading-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <div className="loading-icon">🔄</div>
      <p>Loading...</p>
    </motion.div>
  );
};

export default LoadingScreen;
