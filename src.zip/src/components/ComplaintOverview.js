import React, { useState } from 'react';
import { Box, Typography, Button, Checkbox, FormControlLabel } from '@mui/material';

const ComplaintOverview = ({ nextStep, updateFormData, formData }) => {
  const [isAgreed, setIsAgreed] = useState(false); // To track if the user agrees to the declaration

  const handleAgreementChange = (event) => {
    setIsAgreed(event.target.checked);
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Complaint Overview</Typography>

      {/* Warning paragraph */}
      <Typography variant="body1" paragraph>
        Please note that providing false or misleading information in a complaint is a serious offense. If found guilty of submitting a false complaint, you may face legal consequences under the applicable laws. Ensure that all information provided is true to the best of your knowledge.
      </Typography>

      {/* Promise/Declaration Checkbox */}
      <Box sx={{ marginTop: 2 }}>
        <FormControlLabel
          control={
            <Checkbox
              checked={isAgreed}
              onChange={handleAgreementChange}
              color="primary"
            />
          }
          label="I solemnly declare that the information provided is true to the best of my knowledge, and I understand the consequences of submitting false information."
        />
      </Box>

      <Button
        variant="contained"
        color="primary"
        onClick={nextStep}
        disabled={!isAgreed} // Disable Next button if the user hasn't agreed
        sx={{ marginTop: 2 }}
      >
        Next
      </Button>
    </Box>
  );
};

export default ComplaintOverview;
