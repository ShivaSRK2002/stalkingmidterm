import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Box,
  Typography,
  CircularProgress,
  List,
  ListItem,
  ListItemText,
  Chip,
  Container,
  Grid,
  Card,
  CardContent,
  Button,
} from '@mui/material';

const UserCases = () => {
  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const userid = 116; // The user ID for which to fetch cases
  const categoryid = 24; // The category ID for which to fetch cases
  const token = 'eyJraWQiOiJPMGgyenNCR2lacnlSTzBkNklqdDI1SzdteldpREJKejdhK0lBV2R6XC9yVT0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJlODMxZjMyMC0zMDQxLTcwYzctYjcxYS0zZGUzNjc1ZDVkNmMiLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYmlydGhkYXRlIjoiMjBcLzEwXC8yMDAyIiwiZ2VuZGVyIjoiTWFsZSIsImlzcyI6Imh0dHBzOlwvXC9jb2duaXRvLWlkcC51cy13ZXN0LTIuYW1hem9uYXdzLmNvbVwvdXMtd2VzdC0yX1FQdUpmT2FGYyIsInBob25lX251bWJlcl92ZXJpZmllZCI6ZmFsc2UsImNvZ25pdG86dXNlcm5hbWUiOiJlODMxZjMyMC0zMDQxLTcwYzctYjcxYS0zZGUzNjc1ZDVkNmMiLCJvcmlnaW5fanRpIjoiNjg4MTBhNWYtZDNhMi00Yzk2LWE2OGEtYzZjNjUzOWRlOWYwIiwiYXVkIjoiMm1udjE3dm9hN2U4cTZiYW5sZzBqMHF0aCIsImV2ZW50X2lkIjoiMmFlZTdiNDMtM2FmOC00OGIyLWE2MTgtM2VhNWY2MTYwZTgwIiwidG9rZW5fdXNlIjoiaWQiLCJhdXRoX3RpbWUiOjE3MzE1ODA5NTgsIm5hbWUiOiJTaGl2YSIsInBob25lX251bWJlciI6Iis5MTg4MjU3OTIyNjUiLCJleHAiOjE3MzE2NjczNTgsImlhdCI6MTczMTU4MDk1OCwianRpIjoiMzU5MmIxMTEtMzg3YS00NWJkLTg4ODEtN2Q5MmZjMTJmODI4IiwiZW1haWwiOiJzaGl2YXJhbWFrcnNobm5AZ21haWwuY29tIn0.EXBMHT6-0UqDVzH9_CeA0MeIbKbgXvcdNK80PYRElP3XOt2yvbBIHeluLg26OQbxu1us6l0LPGm3iW2kzlXe79-osWfm9xPqvm-RUQ2a4hofi9bcm2kZmh1fwaMArCtYtWo5q82-MzujTuSRT_sRxuHRnSzsW5gGLQMYbJTQrdnFMTJbK0WjEONM2Jjp-BN9RAS3FtCY4A8-AmW23GXfcijRjMquiE5MwV9GFRYS5DlM1OIzKRz-tZuYO4_hh55oDV3VxfJhNGvXlKSB0T_gyoKOmgNweD663sGqcdCwSwrQGueJCXkXtnxlUAu5AXVFZkvm8Urpi4ymoDo6D6RA5Q'; // Replace with your actual token

  useEffect(() => {
    const fetchCases = async () => {
      try {
        const response = await axios.get(
          'https://7umuvu5ypg.execute-api.eu-west-2.amazonaws.com/GetAll',
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        const parsedBody = JSON.parse(response.data.body);
        const allCases = Array.isArray(parsedBody.items) ? parsedBody.items : [];

        const userCases = allCases
          .map((caseItem) => {
            if (caseItem.categoryid === categoryid && caseItem.userid === userid) {
              return {
                caseId: caseItem.complaintid || 'N/A',
                casestatus: caseItem.casestatus || 'Unknown',
                policeId: caseItem.policeid || 'N/A',
                isFirFiled: caseItem.isfirfiled ? 'Yes' : 'No',
                incidentDetails: JSON.parse(caseItem.individualdetails || '{}'),
              };
            }
            return null;
          })
          .filter(Boolean);

        setCases(userCases);
      } catch (err) {
        setError('Failed to fetch cases. Please try again.');
      } finally {
        setLoading(false);
      }
    };

    fetchCases();
  }, [token]);

  if (loading) {
    return <CircularProgress />;
  }

  if (error) {
    return <Typography color="error">{error}</Typography>;
  }

  if (cases.length === 0) {
    return <Typography>No cases found for user ID {userid} and category ID {categoryid}.</Typography>;
  }

  // Status mapping with descriptions and colors
  const statusMapping = {
    Submitted: { color: 'info', description: 'The initial status when the complaint is first received and logged into the system.' },
    'Under Investigation': { color: 'primary', description: 'The case is actively being reviewed and investigated by officials or law enforcement.' },
    'Pending Information': { color: 'warning', description: 'More information is required from the complainant to proceed.' },
    Resolved: { color: 'success', description: 'The investigation has concluded, and action has been taken.' },
    Closed: { color: 'default', description: 'The case is closed and no further actions will be taken.' },
    Unknown: { color: 'error', description: 'The status of the case is unknown.' },
  };

  return (
    <Container maxWidth="lg" style={{ marginTop: '2rem' }}>
      <Typography variant="h4" gutterBottom>
        Registered Cases
      </Typography>
      <Grid container spacing={3}>
        {cases.map((caseItem, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Card elevation={3}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Case ID: {caseItem.caseId}
                </Typography>
                <Typography variant="subtitle2" color="textSecondary">
                  Police ID: {caseItem.policeId} | FIR Filed: {caseItem.isFirFiled}
                </Typography>

                <Chip
                  label={caseItem.casestatus}
                  color={statusMapping[caseItem.casestatus]?.color || 'error'}
                  size="small"
                  style={{ marginTop: '8px' }}
                />
                <Typography variant="body2" color="textSecondary" style={{ marginTop: '12px' }}>
                  {statusMapping[caseItem.casestatus]?.description || 'No description available.'}
                </Typography>

                <Box mt={2}>
                  <Button variant="contained" color="primary" size="small">
                    View Details
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default UserCases;
