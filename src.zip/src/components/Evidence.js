import React from 'react';
import { Box, Typography, Button } from '@mui/material';

const Evidence = ({ updateFormData, formData, nextStep }) => {
  // Handle Aadhaar file selection
  const handleAadhaarFileChange = (e) => {
    const file = e.target.files[0];
    updateFormData({ aadhaarUpload: file });
  };

  // Handle evidence file selection
  const handleEvidenceFileChange = (e) => {
    const files = Array.from(e.target.files);
    updateFormData({ evidenceFiles: [...(formData.evidenceFiles || []), ...files] });
  };

  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Evidence Upload
      </Typography>

      {/* Aadhaar Upload */}
      <Typography variant="subtitle1" gutterBottom>
        Upload Aadhaar
      </Typography>
      <input
        accept="image/*"
        id="aadhaar-upload"
        type="file"
        onChange={handleAadhaarFileChange}
        style={{ display: 'none' }}
      />
      <label htmlFor="aadhaar-upload">
        <Button variant="outlined" color="primary" component="span">
          Upload Aadhaar
        </Button>
      </label>

      {/* Evidence Upload */}
      <Typography variant="subtitle1" gutterBottom mt={2}>
        Upload Evidence (Images/Videos)
      </Typography>
      <input
        accept="image/*,video/*"
        id="evidence-upload"
        type="file"
        multiple
        onChange={handleEvidenceFileChange}
        style={{ display: 'none' }}
      />
      <label htmlFor="evidence-upload">
        <Button variant="outlined" color="primary" component="span">
          Upload Evidence
        </Button>
      </label>

      {/* Next Button */}
      <Box mt={3}>
        <Button variant="contained" color="primary" onClick={nextStep}>
          Next
        </Button>
      </Box>
    </Box>
  );
};

export default Evidence;
