import React from 'react';
import { Box, Typography, TextField, Button } from '@mui/material';

const ComplainantInformation = ({ prevStep, nextStep, updateFormData, formData }) => {
  // Form validation to ensure all fields are filled before proceeding
  const isFormValid = formData.fullName && formData.contactNumber && formData.emailAddress;

  return (
    <Box>
      <Typography variant="h4" gutterBottom>Complainant Information</Typography>
      
      <TextField
        label="Full Name"
        value={formData.fullName}
        onChange={(e) => updateFormData({ fullName: e.target.value })}
        fullWidth
        margin="normal"
        required
      />
      
      <TextField
        label="Contact Number"
        value={formData.contactNumber}
        onChange={(e) => updateFormData({ contactNumber: e.target.value })}
        fullWidth
        margin="normal"
        required
      />
      
      <TextField
        label="Email Address"
        value={formData.emailAddress}
        onChange={(e) => updateFormData({ emailAddress: e.target.value })}
        fullWidth
        margin="normal"
        required
      />

      {/* Buttons with spacing */}
      <Box sx={{ display: 'flex', justifyContent: 'space-between', marginTop: 2 }}>
        <Button variant="outlined" color="secondary" onClick={prevStep}>
          Previous
        </Button>
        
        <Button
          variant="contained"
          color="primary"
          onClick={nextStep}
          //disabled={!isFormValid} // Disable button if the form is not valid
        >
          Next
        </Button>
      </Box>
    </Box>
  );
};

export default ComplainantInformation;
