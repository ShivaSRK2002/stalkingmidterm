import React from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button, Box, Container, Typography, Grid, Paper, Divider, AppBar, Toolbar, Link } from "@mui/material";
import { ArrowForward, Report, CheckCircle, HelpOutline, ContactSupport } from "@mui/icons-material";

const HomePage = () => {
  const navigate = useNavigate();

  const handleFileComplaint = () => {
    navigate("/complaint-form");
  };

  const handleViewStatus = () => {
    navigate("/user-cases");
  };

  const handleContactUs = () => {
    navigate("/contact-us");
  };

  return (
    <>
      {/* Header */}
      <AppBar position="static" sx={{ backgroundColor: "#1a73e8" }}>
        <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
          <Typography variant="h5" component="div" sx={{ flexGrow: 1, fontWeight: 'bold', textAlign: 'left'}}>
            Stalking Complaint Portal
          </Typography>
          <Button color="inherit" onClick={handleFileComplaint}>Raise Complaint</Button>
          <Button color="inherit" onClick={handleViewStatus}>Track Status</Button>
          <Button color="inherit" onClick={handleContactUs}>Contact Us</Button>
        </Toolbar>
      </AppBar>

      {/* Main Content */}
      <Container
        maxWidth="lg"
        sx={{
          paddingY: 6,
          backgroundColor: "#f8f9fa",
          minHeight: "100vh",
          borderRadius: 2,
          boxShadow: 3,
        }}
      >
        {/* Introduction Section with Motion Effect */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2 }}
          sx={{ textAlign: "center", marginBottom: 5 }}
        >
          <Typography
            variant="h3"
            component="h1"
            gutterBottom
            sx={{ fontSize: "2.5rem", fontWeight: 700, color: "#333", letterSpacing: 1.2, textAlign:"center" }}
          >
            Welcome to the Stalking Complaint Portal
          </Typography>

          <Typography
            variant="body1"
            paragraph
            sx={{
              color: "#555",
              fontSize: "1.25rem",
              fontWeight: 400,
              maxWidth: 650,
              marginX: "auto",
              lineHeight: 1.6,
            }}
          >
            This platform provides a secure, confidential, and professional environment for individuals to raise stalking complaints, track their case status, and get support throughout the process.
          </Typography>
        </motion.div>

        {/* Action Cards */}
        <Grid container spacing={4} justifyContent="center">
          <Grid item xs={12} sm={6} md={4}>
            <Paper elevation={3} sx={{ padding: 3, textAlign: "center", cursor: "pointer" }}>
              <Report fontSize="large" color="primary" />
              <Typography variant="h6" sx={{ marginTop: 1, fontWeight: 600 }}>File a Complaint</Typography>
              <Typography variant="body2" sx={{ color: "#666" }}>
                Submit a complaint securely and professionally. Our officers are here to assist and support you.
              </Typography>
              <Button variant="contained" color="primary" sx={{ marginTop: 2 }} onClick={handleFileComplaint}>
                Raise Complaint <ArrowForward fontSize="small" />
              </Button>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Paper elevation={3} sx={{ padding: 3, textAlign: "center", cursor: "pointer" }}>
              <CheckCircle fontSize="large" color="success" />
              <Typography variant="h6" sx={{ marginTop: 1, fontWeight: 600 }}>Track Complaint Status</Typography>
              <Typography variant="body2" sx={{ color: "#666" }}>
                Stay updated with the latest status of your complaint and see real-time updates.
              </Typography>
              <Button variant="contained" color="primary" sx={{ marginTop: 2 }} onClick={handleViewStatus}>
                View Status <ArrowForward fontSize="small" />
              </Button>
            </Paper>
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <Paper elevation={3} sx={{ padding: 3, textAlign: "center", cursor: "pointer" }}>
              <HelpOutline fontSize="large" color="secondary" />
              <Typography variant="h6" sx={{ marginTop: 1, fontWeight: 600 }}>Guidance & Support</Typography>
              <Typography variant="body2" sx={{ color: "#666" }}>
                Get information on what to expect and access support resources tailored to your needs.
              </Typography>
              <Button variant="contained" color="primary" sx={{ marginTop: 2 }} onClick={handleContactUs}>
                Get Help <ArrowForward fontSize="small" />
              </Button>
            </Paper>
          </Grid>
        </Grid>

        {/* Informative Section */}
        <Box sx={{ marginTop: 6 }}>
          <Divider sx={{ marginY: 4 }} />
          <Typography variant="h4" sx={{ fontWeight: 600, color: "#333", textAlign: "center", marginBottom: 2 }}>
            Know Your Rights & the Law on Stalking in India
          </Typography>
          <Typography
            variant="body1"
            paragraph
            sx={{
              color: "#555",
              fontSize: "1.1rem",
              lineHeight: 1.6,
              maxWidth: 700,
              marginX: "auto",
              textAlign: "center",
            }}
          >
            In India, stalking is a punishable offense under Section 354D of the Indian Penal Code. We aim to provide a safe and supportive platform for individuals to report stalking incidents and access resources to help them navigate the legal process.
          </Typography>
        </Box>
      </Container>

      {/* Footer */}
      <Box sx={{ backgroundColor: "#1a73e8", color: "#fff", paddingY: 4, textAlign: "center", marginTop: 6 }}>
        <Container maxWidth="lg">
          <Grid container spacing={4}>
            <Grid item xs={12} sm={4}>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>About Us</Typography>
              <Typography variant="body2" sx={{ marginTop: 1 }}>
                Our mission is to provide a reliable platform for individuals to safely and confidentially report stalking incidents.
              </Typography>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>Quick Links</Typography>
              <Link href="#" color="inherit" underline="hover" sx={{ display: "block", marginTop: 1 }}>FAQ</Link>
              <Link href="#" color="inherit" underline="hover" sx={{ display: "block" }}>Terms & Conditions</Link>
              <Link href="#" color="inherit" underline="hover" sx={{ display: "block" }}>Privacy Policy</Link>
            </Grid>
            <Grid item xs={12} sm={4}>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>Contact Us</Typography>
              <Typography variant="body2" sx={{ marginTop: 1 }}>Email: support@stalkingcomplaint.com</Typography>
              <Typography variant="body2">Phone: +91 12345 67890</Typography>
              <Typography variant="body2">Address: 123 Main Street, City, India</Typography>
            </Grid>
          </Grid>
          <Divider sx={{ marginY: 4, backgroundColor: "#ffffff60" }} />
          <Typography variant="body2">
            &copy; 2024 Stalking Complaint Portal | All Rights Reserved
          </Typography>
        </Container>
      </Box>
    </>
  );
};

export default HomePage;
