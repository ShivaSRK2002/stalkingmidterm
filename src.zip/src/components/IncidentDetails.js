import React from 'react';
import { Box, Typography, TextField, Button } from '@mui/material';

const IncidentDetails = ({ prevStep, nextStep, updateFormData, formData }) => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>Incident Details</Typography>
      
      <TextField
        label="Location of Incident"
        value={formData.locationOfIncident}
        onChange={(e) => updateFormData({ locationOfIncident: e.target.value })}
        fullWidth
        margin="normal"
      />
      
      <TextField
        label="Date of Incident"
        type="date"  // HTML date input
        value={formData.dateOfIncident || ''}  // default empty string if null
        onChange={(e) => updateFormData({ dateOfIncident: e.target.value })}
        fullWidth
        margin="normal"
        InputLabelProps={{
          shrink: true,  // keeps the label in place
        }}
      />
      
      <TextField
        label="Incident Description"
        value={formData.incidentDescription}
        onChange={(e) => updateFormData({ incidentDescription: e.target.value })}
        fullWidth
        margin="normal"
        multiline
        rows={4}
      />
      
      <Button variant="outlined" color="secondary" onClick={prevStep} sx={{ mt: 2, mr: 2 }}>
        Previous
      </Button>
      <Button variant="contained" color="primary" onClick={nextStep} sx={{ mt: 2 }}>
        Next
      </Button>
    </Box>
  );
};

export default IncidentDetails;
