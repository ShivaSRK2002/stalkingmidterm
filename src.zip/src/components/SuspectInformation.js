import React from 'react';
import { Box, Typography, TextField, Button } from '@mui/material';

const SuspectInformation = ({ prevStep, nextStep, updateFormData, formData }) => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>Suspect Information</Typography>
      <TextField
        label="Suspect Description"
        value={formData.suspectDescription}
        onChange={(e) => updateFormData({ suspectDescription: e.target.value })}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Relation to Complainant"
        value={formData.relationToComplainant}
        onChange={(e) => updateFormData({ relationToComplainant: e.target.value })}
        fullWidth
        margin="normal"
      />
      <Button variant="outlined" color="secondary" onClick={prevStep}>
        Previous
      </Button>
      <Button variant="contained" color="primary" onClick={nextStep}>
        Next
      </Button>
    </Box>
  );
};

export default SuspectInformation;
