import React from 'react';
import { Box, Typography, TextField, Button } from '@mui/material';

const AdditionalDetails = ({ prevStep, nextStep, updateFormData, formData }) => {
  return (
    <Box>
      <Typography variant="h4" gutterBottom>Additional Details</Typography>
      <TextField
        label="Request for Action"
        value={formData.requestForAction}
        onChange={(e) => updateFormData({ requestForAction: e.target.value })}
        fullWidth
        margin="normal"
      />
      <TextField
        label="Admin Comments"
        value={formData.adminComments}
        onChange={(e) => updateFormData({ adminComments: e.target.value })}
        fullWidth
        margin="normal"
      />
      <Button variant="outlined" color="secondary" onClick={prevStep}>
        Previous
      </Button>
      <Button variant="contained" color="primary" onClick={nextStep}>
        Next
      </Button>
    </Box>
  );
};

export default AdditionalDetails;
